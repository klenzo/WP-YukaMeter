# WP-YukaMeter
"Yuka Meter" Is a plugin that will simply display the note, with or without your product icon. Good to know: You must manually insert the note, for the rest, the plugin takes care of it!
