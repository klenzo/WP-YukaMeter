=== Yuka Meter : Share your product's Yuka rating (Manual) ===
Contributors: klenzo
Tags: Yuka, product
Requires at least: 3.6
Tested up to: 5.4
Requires PHP: 5.4
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

"Yuka Meter" Is a plugin that will simply display the note, with or without your product icon. Good to know: You must manually insert the note, for the rest, the plugin takes care of it!

= 1.0 =
Start project
